<?php
declare(strict_types=1);
namespace MyPlot\subcommand;

use MyPlot\Plot;
use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\utils\TextFormat;
use jojoe77777\FormAPI;
use pocketmine\Server;
use pocketmine\event\Listener;
use pocketmine\plugin\PluginBase;
use jojoe77777\FormAPI\CustomForm;
use jojoe77777\FormAPI\SimpleForm;

class InfoSubCommand extends SubCommand
{
	/**
	 * @param CommandSender $sender
	 *
	 * @return bool
	 */
	public function canUse(CommandSender $sender) : bool {
		return ($sender instanceof Player) and $sender->hasPermission("myplot.command.info");
	}

	/**
	 * @param Player $sender
	 * @param string[] $args
	 *
	 * @return bool
	 */
	public function execute(CommandSender $sender, array $args) : bool {
		if(isset($args[0])) {
			if(isset($args[1]) and is_numeric($args[1])) {
				$key = ((int) $args[1] - 1) < 1 ? 1 : ((int) $args[1] - 1);
				/** @var Plot[] $plots */
				$plots = [];
				foreach($this->getPlugin()->getPlotLevels() as $levelName => $settings) {
					$plots = array_merge($plots, $this->getPlugin()->getPlotsOfPlayer($args[0], $levelName));
				}
				if(isset($plots[$key])) {
					$plot = $plots[$key];
        $form = new SimpleForm(function (Player $sender, $data) {
            $result = $data;
            if ($result == null) {
            }
            switch ($result) {
                    case 1:
                    $sender->addTitle("§bCrashGames", "§cby Crasher508");
						break;
						    }
             });
        $helpers = implode(", ", $plot->helpers);
        $denied = implode(", ", $plot->denied);
        $form->setTitle("§l§bPlot Infos");
        $form->setContent(TextFormat::WHITE . "Informationen über Grundstück: " . TextFormat::GREEN . $plot . TextFormat::WHITE . "\n Besitzer: " . TextFormat::GREEN . $plot->owner . TextFormat::WHITE . "\n Name: " . TextFormat::GREEN . $plot->name . TextFormat::WHITE . "\n Helfer: " . TextFormat::GREEN . $helpers . TextFormat::WHITE . "\n Gesperrt: " . TextFormat::GREEN . $denied . TextFormat::WHITE . "\n Biom: " . TextFormat::GREEN . $plot->biome . "\n\n\n\n\n\n\n\n");
        $form->addButton("§cSchließen", 0);
        $form->sendToPlayer($sender);
				}else{
					$sender->sendMessage(TextFormat::RED . $this->translateString("info.notfound"));
				}
			}else{
				return false;
			}
		}else{
			$plot = $this->getPlugin()->getPlotByPosition($sender);
			if($plot === null) {
				$sender->sendMessage(TextFormat::RED . $this->translateString("notinplot"));
				return true;
			}
			$form = new SimpleForm(function (Player $sender, $data) {
            $result = $data;
            if ($result == null) {
            }
            switch ($result) {
                    case 1:
                    $sender->addTitle("§bMyPlot", "§cupdatet by Crasher508");
						break;
						    }
             });
        $helpers = implode(", ", $plot->helpers);
        $denied = implode(", ", $plot->denied);
        $form->setTitle("§l§bPlot Info");
        $form->setContent(TextFormat::WHITE . "Informationen über Grundstück: " . TextFormat::GREEN . $plot . TextFormat::WHITE . "\n Besitzer: " . TextFormat::GREEN . $plot->owner . TextFormat::WHITE . "\n Name: " . TextFormat::GREEN . $plot->name . TextFormat::WHITE . "\n Helfer: " . TextFormat::GREEN . $helpers . TextFormat::WHITE . "\n Gesperrt: " . TextFormat::GREEN . $denied . TextFormat::WHITE . "\n Biom: " . TextFormat::GREEN . $plot->biome . "\n\n\n\n\n\n\n\n");
        $form->addButton("§cSchließen", 0);
        $form->sendToPlayer($sender);
		}
		return true;
	}
}